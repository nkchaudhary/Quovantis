import React from 'react';
import { Link } from 'react-router-dom';

import { userService } from '../_services';

import { ReactTable } from './reactTable';

class HomePage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            user: {},
            users: []
        };
    }

    componentDidMount() {
        this.setState({
            user: JSON.parse(localStorage.getItem('user')),
            users: { loading: true }
        });
        userService.getAll().then(users => this.setState({ users }));
    }

    getData = (users) => {
        users.map((user, index) =>
            <li key={user.id}>
                {user.firstName + ' ' + user.lastName}
            </li>
        )
    }

    render() {
        const { user, users } = this.state;
        return (
            <div className="col-md-12">
                <nav className="navbar navbar-default">
                    <div className="container-fluid">
                        <ul className="nav navbar-nav">
                            <li><a href="#"><h4 className="text-left">Quovantis </h4></a></li>
                        </ul>
                        <ul className="nav navbar-nav navbar-right">
                            <li><a href="#"><span className="glyphicon glyphicon-user"></span><p>
                                <Link to="/login">Logout</Link>
                            </p></a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div className="col-md-12">
                    {/* reactTable not working some issues render every time so i am using normal table */}
                    {users.loading && <em>Loading users details...</em>}
                    {users.length &&
                        <table>
                            <th>ID</th>
                            <th> First Name</th>
                            <th> Last Name</th>
                            <th>Email Id</th>

                            {users.map((user, index) =>
                                <tr key={user.id}>
                                    <td>{user.id}</td>
                                    <td>{user.firstName}</td>
                                    <td>{user.lastName}</td>
                                    <td>{user.email ? user.email : "Data not available"}</td>
                                </tr>

                            )}
                        </table>
                    }
                    <div class="pagination">
                        <a href="#">&laquo;</a>
                        <a href="#">1</a>
                        <a href="#">2</a>
                        <a href="#">3</a>
                        <a href="#">4</a>
                        <a href="#">5</a>
                        <a href="#">6</a>
                        <a href="#">&raquo;</a>
                    </div>

                    {/* <ReactTable
                        data={JSON.parse(localStorage.getItem('user'))}
                        columns={[
                            {
                                Header: "Name",
                                columns: [
                                    {
                                        Header: "First Name",
                                        accessor: "firstName"
                                    },
                                    {
                                        Header: "Last Name",
                                        id: "lastName",
                                        accessor: d => d.lastName
                                    }
                                ]
                            }
                        ]}
                        defaultPageSize={10}
                        className="-striped -highlight"
                    /> */}

                    {/* <div className="col-md-6"><img src="/src/Capture.PNG" /></div> */}

                </div>
            </div>
        );
    }
}

export { HomePage };